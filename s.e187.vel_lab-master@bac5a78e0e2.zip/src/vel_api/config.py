from __future__ import annotations

import ssl
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "development"
    log_level: str = "INFO"
    api_host: str = "127.0.0.1"
    api_port: int = 8000

    postgres_dsn: str = ""
    postgres_schema: str = "public"
    postgres_contracts_table: str = "contracts_dataset_meta_prepared"
    postgres_metadata_table: str = "contract_metadata_all"
    postgres_opportunities_table: str = "opportunities_dataset"
    postgres_pool_min: int = 1
    postgres_pool_max: int = 5
    postgres_statement_timeout_ms: int = 30_000
    max_sql_rows: int = 1_000

    chroma_url: str = ""
    chroma_auth_header: str = "Authorization"
    chroma_auth_scheme: str = ""
    chroma_auth_token: str = ""
    chroma_tenant: str = "default_tenant"
    chroma_database: str = "default_database"
    chroma_contract_collection: str = "IS_contracts_full_main_e5_documents"
    chroma_reference_collection: str = "IS_reference_main_e5"
    chroma_top_k: int = 10
    chroma_candidate_k: int = Field(default=300, ge=1, le=1_000)
    chroma_similarity_threshold: float = 0.5

    llm_base_url: str = ""
    embedding_base_url: str = ""
    llm_api_key: str = ""
    embedding_api_key: str = ""
    ca_cert_file: str = ""
    router_model: str = ""
    sql_model: str = ""
    answer_model: str = ""
    embedding_model: str = ""
    request_timeout_seconds: float = Field(default=45, gt=0)
    max_question_chars: int = Field(default=10_000, gt=0)
    max_file_ids: int = Field(default=500, gt=0)
    max_rag_context_chars: int = Field(default=8_000, gt=0)

    def require_postgres(self) -> None:
        if not self.postgres_dsn:
            raise RuntimeError("POSTGRES_DSN must be configured")

    def require_chroma(self) -> None:
        if not self.chroma_url or not self.chroma_auth_token:
            raise RuntimeError("CHROMA_URL and CHROMA_AUTH_TOKEN must be configured")

    def require_llm(self) -> None:
        if not self.llm_base_url or not self.llm_api_key:
            raise RuntimeError("LLM_BASE_URL and LLM_API_KEY must be configured")

    def require_embedding(self) -> None:
        if not self.embedding_base_url or not self.embedding_api_key:
            raise RuntimeError("EMBEDDING_BASE_URL and EMBEDDING_API_KEY must be configured")


def ssl_verify_setting(settings: Settings) -> bool | ssl.SSLContext:
    if settings.ca_cert_file:
        return ssl.create_default_context(cafile=settings.ca_cert_file)
    return True


@lru_cache
def get_settings() -> Settings:
    return Settings()

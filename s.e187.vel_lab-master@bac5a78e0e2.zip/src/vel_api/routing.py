from __future__ import annotations

import re

import httpx

from vel_api.llm.client import LLMClient
from vel_api.models import Route

PROJECT_ID = re.compile(r"\b\d{7}(?:\.[A-Za-z0-9]+)?\b")
RECENT_YEARS = re.compile(r"\b(?:last|past)\s+\d+\s+years?\b")


def is_broad_contract_search(question: str) -> bool:
    normalized = question.lower()
    return not PROJECT_ID.search(question) and any(
        term in normalized
        for term in (
            "find contracts where",
            "find all contracts",
            "where we have done",
            "past performance",
            "scope of work",
        )
    )


def classify_question(question: str) -> Route:
    normalized = question.lower().strip()
    if normalized in {"hi", "hello", "hey", "good morning", "good afternoon"}:
        return Route.LLM_ONLY
    asks_for_content = any(
        term in normalized
        for term in ("summarize", "summary", "risk", "what does", "explain", "say about")
    )
    if asks_for_content and PROJECT_ID.search(question):
        return Route.SQL_AND_DOCS_ALL
    if any(
        term in normalized
        for term in (
            "how do i",
            "how do you",
            "how to",
            "policy",
            "procedure",
            "guidance",
            "manual",
            "salesforce",
        )
    ):
        return Route.REFERENCE_DOCS
    if "base contract" in normalized:
        return Route.SQL_AND_DOCS_BASE if asks_for_content else Route.SQL_ONLY
    if RECENT_YEARS.search(normalized) and any(
        term in normalized
        for term in ("contract", "capability", "integration", "sow", "pws", "performance")
    ):
        return Route.SQL_AND_DOCS_BASE
    if asks_for_content or any(
        term in normalized
        for term in (
            "have we ever",
            "capability",
            "supporting",
            "scope of work",
            "past performance",
            "statement of work",
            "sow",
            "pws",
            "find all contracts",
            "where we have done",
        )
    ):
        return Route.DOCS_ONLY
    if any(
        term in normalized for term in ("contract", "project", "opportunit", "pipeline", "modified")
    ):
        return Route.SQL_ONLY
    return Route.LLM_ONLY


class RouteClassifier:
    def __init__(self, llm: LLMClient, model: str) -> None:
        self._llm = llm
        self._model = model

    async def classify(self, question: str) -> Route:
        if is_broad_contract_search(question) and not RECENT_YEARS.search(question.lower()):
            return Route.DOCS_ONLY
        system = (
            "Classify the question into exactly one route and return only JSON: "
            '{"route":"sql_only|sql_and_docs_all|sql_and_docs_base|docs_only|reference_docs|'
            'llm_only"}. '
            "sql_only is for structured attributes, lists, counts, dates, or opportunity data. "
            "sql_and_docs_all requires document content after filtering with a specific project "
            "identifier. "
            "sql_and_docs_base requires document content after filtering by metadata without a "
            "specific project ID, such as a date range. "
            "docs_only is broad contract-document content search, including past-performance, "
            "capability, SOW/PWS, and opportunity-scope matching. reference_docs is company "
            "how-to, Salesforce, policy, "
            "or manual guidance. llm_only needs no internal data."
        )
        try:
            result = await self._llm.json_complete(self._model, system, question)
            return Route(str(result["route"]))
        except (httpx.HTTPError, KeyError, TypeError, ValueError):
            return classify_question(question)

from __future__ import annotations

import re
from typing import Any

import asyncpg

from vel_api.config import Settings
from vel_api.models import QueryPlan, Record
from vel_api.postgres.catalog import columns_for_entity, table_for_entity

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")


def quote_identifier(value: str) -> str:
    if not IDENTIFIER.fullmatch(value):
        raise ValueError(f"Invalid configured SQL identifier: {value!r}")
    return f'"{value}"'


class PostgresRepository:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._pool: asyncpg.Pool[asyncpg.Record] | None = None

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    async def _get_pool(self) -> asyncpg.Pool[asyncpg.Record]:
        if self._pool is None:
            self._settings.require_postgres()
            self._pool = await asyncpg.create_pool(
                self._settings.postgres_dsn,
                min_size=self._settings.postgres_pool_min,
                max_size=self._settings.postgres_pool_max,
                server_settings={
                    "statement_timeout": str(self._settings.postgres_statement_timeout_ms)
                },
            )
        return self._pool

    async def fetch(self, plan: QueryPlan) -> list[Record]:
        query, parameters = self._build_query(plan)
        pool = await self._get_pool()
        async with pool.acquire() as connection:
            rows = await connection.fetch(query, *parameters)
        return [dict(row) for row in rows]

    def _build_query(self, plan: QueryPlan) -> tuple[str, list[Any]]:
        allowed_columns = columns_for_entity(plan.entity)
        requested = plan.columns or sorted(allowed_columns)
        if not set(requested).issubset(allowed_columns):
            raise ValueError("Query plan requested a column outside the approved catalog")
        if plan.order_by is not None and plan.order_by not in allowed_columns:
            raise ValueError("Query plan requested an unapproved ordering column")
        if plan.distinct and plan.order_by and plan.order_by not in requested:
            requested = [*requested, plan.order_by]
        columns = ", ".join(quote_identifier(column) for column in requested)
        distinct = "DISTINCT " if plan.distinct else ""
        schema = quote_identifier(self._settings.postgres_schema)
        table = quote_identifier(table_for_entity(self._settings, plan.entity))
        clauses: list[str] = []
        parameters: list[Any] = []
        for column, value in plan.filters.items():
            if column not in allowed_columns:
                raise ValueError("Query plan requested a filter outside the approved catalog")
            # Salesforce metadata fields are stored as text, including numeric-looking project IDs.
            parameters.append(str(value) if plan.entity == "contract_metadata" else value)
            clauses.append(f"{quote_identifier(column)} = ${len(parameters)}")
        if plan.entity == "contract_metadata" and plan.active_only:
            clauses.append('"Closeout_Time_Standard__c"::date > CURRENT_DATE')
        if plan.entity == "contract_metadata" and plan.base_contract_only:
            parameters.append("Base Contract")
            clauses.append(f'"Contracts_x0020_Subfolder" = ${len(parameters)}')
        if plan.entity == "contract_metadata" and plan.modified_within_years is not None:
            parameters.append(plan.modified_within_years)
            clauses.append(
                f'"lastModifiedDateTime"::timestamptz >= '
                f"CURRENT_DATE - (${len(parameters)} * INTERVAL '1 year')"
            )
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        order = ""
        if plan.order_by:
            direction = "DESC" if plan.descending else "ASC"
            order = f" ORDER BY {quote_identifier(plan.order_by)} {direction}"
        parameters.append(min(plan.limit, self._settings.max_sql_rows))
        sql = (
            f"SELECT {distinct}{columns} FROM {schema}.{table}{where}{order} "
            f"LIMIT ${len(parameters)}"
        )
        return sql, parameters

from __future__ import annotations

import json
from typing import Protocol

from pydantic import ValidationError

from vel_api.models import QueryPlan
from vel_api.postgres.catalog import columns_for_entity


class JSONCompletionClient(Protocol):
    async def json_complete(self, model: str, system: str, user: str) -> dict[str, object]: ...


class QueryPlanner:
    def __init__(self, llm: JSONCompletionClient, model: str) -> None:
        self._llm = llm
        self._model = model

    async def plan(self, question: str, entity: str) -> QueryPlan:
        allowed_columns = sorted(columns_for_entity(entity))
        system = (
            "Create a PostgreSQL query plan, not SQL. Return one JSON object matching: "
            '{"entity": string, "columns": [string], "filters": {string: string|number|boolean}, '
            '"limit": integer, "order_by": string|null, "descending": boolean, '
            '"distinct": boolean, '
            '"active_only": boolean, "base_contract_only": boolean, '
            '"modified_within_years": integer|null}. '
            f"The entity must be {entity!r}. Allowed columns: {json.dumps(allowed_columns)}. "
            "For a dotted project ID use Project_ID__c; for exactly seven digits use Project. "
            "Always return project IDs in filters as JSON strings, never numbers. "
            "For project-level properties set distinct=true. For latest modifications use "
            "Contracts_x0020_Subfolder='Modifications', order_by=lastModifiedDateTime, "
            "descending=true. Set active_only only when the user requests active contracts. "
            "For 'last N years' document requests, set modified_within_years=N. "
            "Set base_contract_only only "
            "when the user requests base-contract scope. Never invent columns or filters."
        )
        try:
            result = await self._llm.json_complete(self._model, system, question)
            plan = QueryPlan.model_validate(result)
        except (ValidationError, ValueError, KeyError) as exc:
            raise ValueError("The SQL planner returned an invalid constrained query plan") from exc
        if plan.entity != entity:
            raise ValueError("The SQL planner returned the wrong query entity")
        allowed = columns_for_entity(entity)
        if not set(plan.columns).issubset(allowed):
            raise ValueError("The SQL planner returned unapproved result columns")
        if not set(plan.filters).issubset(allowed):
            raise ValueError("The SQL planner returned unapproved filters")
        if plan.order_by is not None and plan.order_by not in allowed:
            raise ValueError("The SQL planner returned an unapproved ordering column")
        return plan

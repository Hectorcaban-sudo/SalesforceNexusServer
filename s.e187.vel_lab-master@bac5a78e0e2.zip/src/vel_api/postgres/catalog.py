from __future__ import annotations

from vel_api.config import Settings

CONTRACT_COLUMNS = frozenset(
    {
        "Project_ID__c",
        "TM_TOMA__Exercised_Contract_Value__c",
        "Business_Area__c",
        "Closeout_Time_Standard__c",
        "Finance_Analyst__r.Name",
        "ContractAdministrator__r.Name",
        "Contract_Administrator_Email_Id__c",
        "Contract_Manager__r.Name",
        "Contracting_Officer__r.Name",
        "Contracting_Officer_Email__c",
        "Contracts_Director__r.Name",
        "Technical_Director__r.Name",
        "Operations_Director__r.Name",
        "Program_Area_Lead__r.Name",
        "Program_Manager__r.Name",
        "Program_Manager_Email_Id__c",
        "Subcontract_Admin__r.Name",
        "Subcontract_Manager__c",
        "Contract_Name",
        "TM_TOMA__Contract_Type__c",
        "name",
        "link",
        "lastModifiedDateTime",
        "drive_id",
        "Project",
        "Project_x003a_PCN",
        "Contracts_x0020_Subfolder",
    }
)

OPPORTUNITY_COLUMNS = frozenset(
    {
        "Id",
        "LastModifiedDate",
        "Name",
        "Description",
        "Capabilities__c",
        "Capability_Areas__c",
        "Sub_Capability__c",
        "Project_Name__c",
        "Business_Area__c",
        "StageName",
        "Status__c",
        "Proposal_Status__c",
        "Amount",
        "Pipeline_Total__c",
        "Award_Date_Formula__c",
        "FedCapture__Our_Role__c",
    }
)


def table_for_entity(settings: Settings, entity: str) -> str:
    if entity == "contract_metadata":
        return settings.postgres_contracts_table
    if entity == "opportunities":
        return settings.postgres_opportunities_table
    raise ValueError(f"Unsupported query entity: {entity}")


def columns_for_entity(entity: str) -> frozenset[str]:
    if entity == "contract_metadata":
        return CONTRACT_COLUMNS
    if entity == "opportunities":
        return OPPORTUNITY_COLUMNS
    raise ValueError(f"Unsupported query entity: {entity}")

from __future__ import annotations

from vel_api.postgres.repositories import quote_identifier

PREPARED_COLUMNS = (
    "Project_ID__c",
    "TM_TOMA__Exercised_Contract_Value__c",
    "Business_Area__c",
    "Closeout_Time_Standard__c",
    "Finance_Analyst__r.Name",
    "ContractAdministrator__r.Name",
    "Contract_Administrator_Email_Id__c",
    "Contract_Manager__r.Name",
    "Contracting_Officer__r.Name",
    "Contracting_Officer_Email__c",
    "Contracts_Director__r.Name",
    "Technical_Director__r.Name",
    "Operations_Director__r.Name",
    "Program_Area_Lead__r.Name",
    "Program_Manager__r.Name",
    "Program_Manager_Email_Id__c",
    "Subcontract_Admin__r.Name",
    "Subcontract_Manager__c",
    "TM_TOMA__Contract_Type__c",
)


def preparation_sql(schema: str, contracts: str, metadata: str, target: str) -> str:
    def qualified(table: str) -> str:
        return f"{quote_identifier(schema)}.{quote_identifier(table)}"

    contract_columns = ",\n    ".join(
        f"c.{quote_identifier(column)}" for column in PREPARED_COLUMNS
    )
    return f"""CREATE OR REPLACE TABLE {qualified(target)} AS
WITH contracts_one_per_project AS (
    SELECT DISTINCT ON (split_part("Project_ID__c", '.', 1)) *
    FROM {qualified(contracts)}
    ORDER BY split_part("Project_ID__c", '.', 1), "Id"
)
SELECT
    {contract_columns},
    c."Name" AS "Contract_Name",
    m."name", m."link", m."lastModifiedDateTime", m."drive_id", m."Project",
    m."Project_x003a_PCN", m."Contracts_x0020_Subfolder"
FROM contracts_one_per_project AS c
RIGHT JOIN {qualified(metadata)} AS m
    ON split_part(c."Project_ID__c", '.', 1) = m."Project";"""

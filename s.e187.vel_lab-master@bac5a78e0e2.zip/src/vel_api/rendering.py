from __future__ import annotations

from collections.abc import Iterable

from vel_api.models import Record, Source


def sources_from_records(records: Iterable[Record]) -> list[Source]:
    seen: set[tuple[str, str]] = set()
    sources: list[Source] = []
    for record in records:
        link = record.get("link")
        if not isinstance(link, str) or not link:
            continue
        name = record.get("name") or record.get("Contract_Name") or link
        source = (str(name), link)
        if source not in seen:
            seen.add(source)
            sources.append(Source(name=source[0], link=source[1]))
    return sources


def render_records(records: list[Record]) -> str:
    if not records:
        return "No matching records were found."
    lines: list[str] = []
    for record in records:
        visible = {key: value for key, value in record.items() if key != "drive_id"}
        lines.append(
            ", ".join(f"{key}: {value}" for key, value in visible.items() if value is not None)
        )
    return "\n".join(lines)


def public_records(records: list[Record]) -> list[Record]:
    return [
        {key: value for key, value in record.items() if key != "drive_id"} for record in records
    ]

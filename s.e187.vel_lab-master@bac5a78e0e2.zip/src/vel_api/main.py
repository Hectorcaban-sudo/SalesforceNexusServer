from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from vel_api.chroma.client import ChromaClient
from vel_api.config import Settings, get_settings
from vel_api.llm.client import LLMClient
from vel_api.postgres.repositories import PostgresRepository
from vel_api.workflow import Workflow


class QuestionRequest(BaseModel):
    question: str = Field(min_length=1)


class ApiServices:
    def __init__(self, settings: Settings) -> None:
        self.llm = LLMClient(settings)
        self.postgres = PostgresRepository(settings)
        self.chroma = ChromaClient(settings, self.llm)
        self.workflow = Workflow(settings, self.postgres, self.chroma, self.llm)

    async def close(self) -> None:
        await self.postgres.close()
        await self.chroma.close()
        await self.llm.close()


def _require_text(value: str, field: str) -> None:
    if not value.strip():
        raise HTTPException(status_code=400, detail=f"{field} must not be blank")


def create_app(
    *, workflow: Any | None = None, chroma: Any | None = None, settings: Settings | None = None
) -> FastAPI:
    configured_settings = settings or get_settings()
    services: ApiServices | None = None
    if workflow is None or chroma is None:
        services = ApiServices(configured_settings)
        workflow = services.workflow
        chroma = services.chroma

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        yield
        if services is not None:
            await services.close()

    app = FastAPI(
        title="Velocity API",
        version="0.1.0",
        description="HTTP API for contract, opportunity, and document retrieval.",
        lifespan=lifespan,
    )

    @app.get("/health", tags=["system"])
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/ask", tags=["workflow"])
    async def ask(request: QuestionRequest) -> dict[str, Any]:
        _require_text(request.question, "question")
        try:
            return (await workflow.ask(request.question)).model_dump()
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except httpx.TimeoutException as exc:
            raise HTTPException(status_code=504, detail="A retrieval service timed out") from exc
        except httpx.TransportError as exc:
            raise HTTPException(
                status_code=502, detail="A retrieval service could not be reached"
            ) from exc

    return app


app = create_app()


def main() -> None:
    import uvicorn

    settings = get_settings()
    uvicorn.run(app, host=settings.api_host, port=settings.api_port)

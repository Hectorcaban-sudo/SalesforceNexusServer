"""Standalone FastAPI service for the Velocity workflow."""

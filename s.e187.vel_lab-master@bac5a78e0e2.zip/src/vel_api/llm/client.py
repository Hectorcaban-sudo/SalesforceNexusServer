from __future__ import annotations

import json
from typing import Any

import httpx

from vel_api.config import Settings, ssl_verify_setting


class LLMClient:
    def __init__(
        self,
        settings: Settings,
        client: httpx.AsyncClient | None = None,
        embedding_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._settings = settings
        self._client = client or httpx.AsyncClient(
            base_url=settings.llm_base_url.rstrip("/") + "/",
            headers={"Authorization": f"Bearer {settings.llm_api_key}"},
            timeout=settings.request_timeout_seconds,
            verify=ssl_verify_setting(settings),
        )
        self._owns_client = client is None
        if embedding_client is not None:
            self._embedding_client = embedding_client
            self._owns_embedding_client = False
        elif client is not None:
            self._embedding_client = client
            self._owns_embedding_client = False
        else:
            embedding_base_url = settings.embedding_base_url or settings.llm_base_url
            self._embedding_client = httpx.AsyncClient(
                base_url=embedding_base_url.rstrip("/") + "/",
                headers={"apikey": settings.embedding_api_key},
                timeout=settings.request_timeout_seconds,
                verify=ssl_verify_setting(settings),
            )
            self._owns_embedding_client = True
        self._embedding_model: str | None = settings.embedding_model or None

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
        if self._owns_embedding_client:
            await self._embedding_client.aclose()

    async def complete(self, model: str, system: str, user: str) -> str:
        response = await self._client.post(
            "chat/completions",
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": 0,
            },
        )
        response.raise_for_status()
        return str(response.json()["choices"][0]["message"]["content"])

    async def json_complete(self, model: str, system: str, user: str) -> dict[str, Any]:
        response = await self._client.post(
            "chat/completions",
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": 0,
                "response_format": {"type": "json_object"},
            },
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        if not isinstance(content, str):
            raise ValueError("LLM returned a non-text JSON response")
        result = json.loads(content)
        if not isinstance(result, dict):
            raise ValueError("LLM JSON response must be an object")
        return result

    async def embed(self, text: str) -> list[float]:
        if not self._settings.embedding_api_key:
            raise RuntimeError("EMBEDDING_API_KEY must be configured")
        if self._embedding_model is None:
            response = await self._embedding_client.get("models")
            response.raise_for_status()
            models = response.json().get("data", [])
            if not models or not isinstance(models[0], dict) or not models[0].get("id"):
                raise RuntimeError("Embedding service returned no model")
            self._embedding_model = str(models[0]["id"])
        response = await self._embedding_client.post(
            "embeddings", json={"model": self._embedding_model, "input": text}
        )
        response.raise_for_status()
        return [float(value) for value in response.json()["data"][0]["embedding"]]

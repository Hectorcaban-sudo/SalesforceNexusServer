from __future__ import annotations

import math
import re
from typing import Any

KEYWORDS = re.compile(r"[a-z0-9]{3,}")
BM25_K1 = 1.5
BM25_B = 0.75


def drive_id_filter(file_ids: list[str]) -> dict[str, dict[str, list[str]]] | None:
    return {"drive_id": {"$in": file_ids}} if file_ids else None


def normalize_results(results: dict[str, Any], threshold: float | None) -> list[dict[str, Any]]:
    documents = results.get("documents", [[]])[0] or []
    metadatas = results.get("metadatas", [[]])[0] or []
    distances = results.get("distances", [[]])[0] or []
    chunks: list[dict[str, Any]] = []
    for index, document in enumerate(documents):
        metadata = metadatas[index] if index < len(metadatas) and metadatas[index] else {}
        distance = distances[index] if index < len(distances) else None
        score = 1 - distance if isinstance(distance, int | float) else None
        if threshold is not None and score is not None and score < threshold:
            continue
        chunks.append(
            {
                "content": str(document),
                "name": metadata.get("name") or metadata.get("source"),
                "link": metadata.get("link"),
                "score": score,
            }
        )
    return chunks


def hybrid_rank_results(query: str, results: dict[str, Any], limit: int) -> list[dict[str, Any]]:
    documents = results.get("documents", [[]])[0] or []
    metadatas = results.get("metadatas", [[]])[0] or []
    distances = results.get("distances", [[]])[0] or []
    query_terms = set(KEYWORDS.findall(query.lower()))
    numeric_distances = [float(value) for value in distances if isinstance(value, int | float)]
    best_distance = min(numeric_distances, default=0.0)
    worst_distance = max(numeric_distances, default=best_distance)
    distance_span = worst_distance - best_distance
    tokenized_documents = [
        KEYWORDS.findall(f"{metadata.get('name', '')} {document}".lower())
        for document, metadata in zip(documents, metadatas, strict=False)
    ]
    average_length = (
        sum(map(len, tokenized_documents)) / len(tokenized_documents) if documents else 0.0
    )
    document_frequency = {
        term: sum(term in set(tokens) for tokens in tokenized_documents) for term in query_terms
    }
    bm25_scores: list[float] = []
    for tokens in tokenized_documents:
        term_frequency = {term: tokens.count(term) for term in query_terms}
        score = 0.0
        for term, frequency in term_frequency.items():
            if not frequency:
                continue
            inverse_frequency = math.log(
                1
                + (
                    (len(tokens) - document_frequency[term] + 0.5)
                    / (document_frequency[term] + 0.5)
                )
            )
            denominator = frequency + BM25_K1 * (
                1 - BM25_B + BM25_B * (len(tokens) / average_length)
            )
            score += inverse_frequency * (frequency * (BM25_K1 + 1) / denominator)
        bm25_scores.append(score)
    max_bm25 = max(bm25_scores, default=0.0)
    chunks: list[dict[str, Any]] = []
    for index, document in enumerate(documents):
        metadata = metadatas[index] if index < len(metadatas) and metadatas[index] else {}
        distance = distances[index] if index < len(distances) else None
        semantic_score = (
            1.0 - ((float(distance) - best_distance) / distance_span)
            if isinstance(distance, int | float) and distance_span
            else 1.0
        )
        bm25_score = bm25_scores[index] if index < len(bm25_scores) else 0.0
        keyword_score = bm25_score / max_bm25 if max_bm25 else 0.0
        chunks.append(
            {
                "content": str(document),
                "name": metadata.get("name") or metadata.get("source"),
                "link": metadata.get("link"),
                "score": semantic_score,
                "bm25_score": bm25_score,
                "keyword_score": keyword_score,
                "hybrid_score": (semantic_score + keyword_score) / 2,
            }
        )
    return sorted(chunks, key=lambda chunk: float(chunk["hybrid_score"]), reverse=True)[:limit]

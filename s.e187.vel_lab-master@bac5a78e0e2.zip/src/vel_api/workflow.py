from __future__ import annotations

import re

from vel_api.chroma.client import ChromaClient
from vel_api.config import Settings
from vel_api.llm.client import LLMClient
from vel_api.models import Answer, Record, Route
from vel_api.postgres.planner import QueryPlanner
from vel_api.postgres.repositories import PostgresRepository
from vel_api.rendering import render_records, sources_from_records
from vel_api.routing import RouteClassifier

RECENT_YEARS = re.compile(r"\b(?:last|past)\s+(\d+)\s+years?\b", re.IGNORECASE)


class Workflow:
    def __init__(
        self,
        settings: Settings,
        postgres: PostgresRepository,
        chroma: ChromaClient,
        llm: LLMClient,
    ) -> None:
        self._settings = settings
        self._postgres = postgres
        self._chroma = chroma
        self._llm = llm
        self._planner = QueryPlanner(llm, settings.sql_model)
        self._router = RouteClassifier(llm, settings.router_model)

    async def ask(self, question: str) -> Answer:
        if not question.strip():
            raise ValueError("question must not be blank")
        if len(question) > self._settings.max_question_chars:
            raise ValueError("question exceeds MAX_QUESTION_CHARS")
        route = await self._router.classify(question)
        if route is Route.SQL_ONLY:
            records = await self.query_structured(question)
            return await self._structured_answer(question, route, records)
        if route in {Route.SQL_AND_DOCS_ALL, Route.SQL_AND_DOCS_BASE}:
            records = await self.query_contracts(
                question,
                base_only="base contract" in question.lower(),
                identifiers_only=True,
            )
            file_ids = [str(record["drive_id"]) for record in records if record.get("drive_id")]
            chunks = await self._chroma.search_contracts(question, file_ids)
            return await self._grounded_answer(question, route, chunks)
        if route is Route.DOCS_ONLY:
            return await self._grounded_answer(
                question, route, await self._chroma.search_contracts(question)
            )
        if route is Route.REFERENCE_DOCS:
            return await self._grounded_answer(
                question, route, await self._chroma.search_reference(question)
            )
        return Answer(
            answer=await self._llm.complete(
                self._settings.answer_model,
                "Answer concisely without claiming to access internal data.",
                question,
            ),
            route=route,
        )

    async def query_structured(self, question: str) -> list[Record]:
        entity = (
            "opportunities"
            if "opportunit" in question.lower() or "pipeline" in question.lower()
            else "contract_metadata"
        )
        return await self._postgres.fetch(await self._planner.plan(question, entity))

    async def query_contracts(
        self, question: str, base_only: bool = False, identifiers_only: bool = False
    ) -> list[Record]:
        plan = await self._planner.plan(question, "contract_metadata")
        plan.base_contract_only = base_only or plan.base_contract_only
        if plan.modified_within_years is None:
            recent_years = RECENT_YEARS.search(question)
            if recent_years is not None:
                plan.modified_within_years = int(recent_years.group(1))
        if identifiers_only:
            plan.columns = ["drive_id", "link", "name"]
            if plan.distinct and plan.order_by and plan.order_by not in plan.columns:
                plan.columns.append(plan.order_by)
        return await self._postgres.fetch(plan)

    async def _grounded_answer(self, question: str, route: Route, chunks: list[Record]) -> Answer:
        unique_chunks: list[Record] = []
        seen_sources: set[tuple[str, str]] = set()
        for chunk in chunks:
            source = (str(chunk.get("name") or ""), str(chunk.get("link") or ""))
            if source not in seen_sources:
                seen_sources.add(source)
                unique_chunks.append(chunk)
        sources = sources_from_records(unique_chunks)
        if not unique_chunks:
            message = (
                "The provided context doesn't cover this."
                if route is Route.REFERENCE_DOCS
                else "No relevant document content was found."
            )
            return Answer(answer=message, route=route, sources=sources)
        content_limit = max(400, self._settings.max_rag_context_chars // len(unique_chunks))
        context = "\n\n".join(
            f"Source: {chunk.get('name') or 'document'}\n"
            f"Link: {chunk.get('link') or ''}\nContent: {str(chunk['content'])[:content_limit]}"
            for chunk in unique_chunks
        )
        answer = await self._llm.complete(
            self._settings.answer_model,
            "Answer using only the supplied context. Keep the answer to four sentences or fewer. "
            "Include relevant plain-text links. Never expose internal drive IDs.",
            f"Question: {question}\n\nContext:\n{context}",
        )
        return Answer(answer=answer, route=route, sources=sources)

    async def _structured_answer(
        self, question: str, route: Route, records: list[Record]
    ) -> Answer:
        sources = sources_from_records(records)
        if not records:
            return Answer(answer="No matching records were found.", route=route, sources=sources)
        answer = await self._llm.complete(
            self._settings.answer_model,
            "Answer only from the supplied structured records. Be concise, include relevant "
            "plain-text links, and never expose internal drive IDs.",
            f"Question: {question}\n\nStructured records:\n{render_records(records)}",
        )
        return Answer(answer=answer, route=route, sources=sources)

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class Route(StrEnum):
    SQL_ONLY = "sql_only"
    SQL_AND_DOCS_ALL = "sql_and_docs_all"
    SQL_AND_DOCS_BASE = "sql_and_docs_base"
    DOCS_ONLY = "docs_only"
    REFERENCE_DOCS = "reference_docs"
    LLM_ONLY = "llm_only"


class Source(BaseModel):
    name: str
    link: str


class Answer(BaseModel):
    answer: str
    route: Route
    sources: list[Source] = Field(default_factory=list)


class QueryPlan(BaseModel):
    entity: str
    columns: list[str] = Field(default_factory=list)
    filters: dict[str, str | int | float | bool] = Field(default_factory=dict)
    limit: int = 100
    order_by: str | None = None
    descending: bool = False
    distinct: bool = False
    active_only: bool = False
    base_contract_only: bool = False
    modified_within_years: int | None = Field(default=None, gt=0)


Record = dict[str, Any]

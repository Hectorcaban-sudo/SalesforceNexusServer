CREATE OR REPLACE TABLE "public"."contracts_dataset_meta_prepared" AS
WITH contracts_one_per_project AS (
    SELECT DISTINCT ON (split_part("Project_ID__c", '.', 1)) *
    FROM "public"."contracts_dataset"
    ORDER BY split_part("Project_ID__c", '.', 1), "Id"
)
SELECT
    c."Project_ID__c",
    c."TM_TOMA__Exercised_Contract_Value__c",
    c."Business_Area__c",
    c."Closeout_Time_Standard__c",
    c."Finance_Analyst__r.Name",
    c."ContractAdministrator__r.Name",
    c."Contract_Administrator_Email_Id__c",
    c."Contract_Manager__r.Name",
    c."Contracting_Officer__r.Name",
    c."Contracting_Officer_Email__c",
    c."Contracts_Director__r.Name",
    c."Technical_Director__r.Name",
    c."Operations_Director__r.Name",
    c."Program_Area_Lead__r.Name",
    c."Program_Manager__r.Name",
    c."Program_Manager_Email_Id__c",
    c."Subcontract_Admin__r.Name",
    c."Subcontract_Manager__c",
    c."TM_TOMA__Contract_Type__c",
    c."Name" AS "Contract_Name",
    m."name",
    m."link",
    m."lastModifiedDateTime",
    m."drive_id",
    m."Project",
    m."Project_x003a_PCN",
    m."Contracts_x0020_Subfolder"
FROM contracts_one_per_project AS c
RIGHT JOIN "public"."contract_metadata_all" AS m
    ON split_part(c."Project_ID__c", '.', 1) = m."Project";

# Custom contract / project object

Working prompt in the org today: **Summarize this contract vehicle record**.

That is General Salesforce (record fields), not Nexus RAG.

Assumed object API name on the Contract Agent permission set: `Contract_Vehicle__c`.
If Setup → Object Manager shows a different name, change that `objectPermissions` entry before deploy.

Also grant field-level security on every Contract Vehicle field the summary should include, and include the object in Query Records / Get Record Details / Summarize Record for the agent.

# Nexus AI Agentforce (Salesforce DX)

Two **Employee** Agentforce agents that share the same Apex RAG actions:

| Agent | Job |
| --- | --- |
| **Nexus Opportunity Agent** | Basic Salesforce Opportunity/Account questions **and** past-performance RAG |
| **Nexus Contract Agent** | Basic Salesforce Contract/Account questions **and** document / error-guidance RAG |

The external RAG corpus holds statements of work, PWS, user/training manuals, and project metadata. Submit and Get must both run; Ask Nexus AI does that in one Agentforce action.

```
Preferred:
User question → Ask Nexus AI (submit event, then HTTP get, return Message)

Fallback, same turn only:
Submit Nexus AI Chat Request → Get Nexus AI Chat Response (required)
```

## Project layout

```
nexus-ai-agentforce/
  force-app/main/default/
    classes/                  Apex invocable actions (kept original class names)
    objects/NexusAI_Chat_Request__e/
    remoteSiteSettings/       Power Automate host
    genAiFunctions/           Agent actions wrapping the Apex classes
    genAiPlugins/             Topics (subagents) for each job-to-be-done
    permissionsets/
  specs/                      Agent design specs + sample utterances
  manifest/package.xml
```

Class names keep the original spelling (`Intergration`, `Reqesponse`, `mesage`) so existing tested wiring still matches.

## What changed from your tested Apex

- Invocable **labels and descriptions** are written for the Agentforce planner (when to call which action).
- Submit action uses `UserInfo.getUserId()` instead of a hardcoded user Id.
- Submit reuses `sessionID` when the agent already has a conversation Id; otherwise it generates one.
- Remote Site Setting added so the HTTP callout can deploy.
- Platform Event stub included. **If the event already exists in the org, exclude `CustomObject` from the deploy** or retrieve the org version first.

## Deploy

```bash
sf org login web --alias nexus
sf project deploy start --source-dir force-app --target-org nexus
```

If the platform event already exists:

```bash
sf project deploy start \
  --metadata ApexClass \
  --metadata RemoteSiteSetting \
  --metadata GenAiFunction \
  --metadata GenAiPlugin \
  --metadata PermissionSet \
  --target-org nexus
```

Assign a **separate** permission set to each Agent User:

| Permission set API name | Assign to |
| --- | --- |
| `Nexus_Opportunity_Agent` | Opportunity agent user + testers |
| `Nexus_Contract_Agent` | Contract agent user + testers |

Both include the two Nexus Apex classes (read-only CRM objects listed in each set). Attach standard Employee CRM actions in Agent Builder so General Salesforce questions query the org instead of RAG.

Add a **Remote Site** is already in source. If you later move the URL to a Named Credential, change `RAG_ENDPOINT` in `NexusAIResponseIntergrationService` to `callout:Nexus_RAG/...`.

## Create the two Employee agents in the org

Agentforce Employee agent shells (Bot + PlannerBundle) are safest created in Setup, then retrieved. Topics and actions in this repo can be attached after deploy.

1. Setup → Agentforce Agents → **New Agent** → Employee agent.
2. Name: `Nexus Opportunity Agent`.
3. Add topics **General Salesforce** and **Opportunity Past Performance**.
4. Add actions:
   - Standard CRM actions (Identify Record by Name, Query Records, Get Record Details)
   - Ask Nexus AI (preferred)
   - Submit Nexus AI Chat Request
   - Get Nexus AI Chat Response (required whenever Submit is used)
5. Repeat for **Nexus Contract Agent** with topics:
   - General Salesforce
   - Contract Documents
   - Contract Error Guidance
6. Assign the matching permission set to that agent's Agent User.
7. Activate the agent version.
8. Retrieve so the Bot / GenAiPlannerBundle live in source:

```bash
sf project retrieve start --metadata "Agent:Nexus_Opportunity_Agent" --target-org nexus
sf project retrieve start --metadata "Agent:Nexus_Contract_Agent" --target-org nexus
```

(`Agent:` is the DX pseudo-type that pulls Bot + BotVersion + planner + topics + actions.)

If `GenAiPlugin` XML fails validation on your API version, create the same topics in Agentforce Assets (clicks) using the instruction text in those XML files and in `specs/*.yaml`.

## Action contract (planner)

Basic Salesforce questions use Identify Record by Name, Query Records, or Get Record Details. Do not call Nexus RAG for those.

RAG questions (past performance, SOW/PWS, project docs, contract errors):

1. Build the user message with identifiers and error text **verbatim**.
2. Call **Submit Nexus AI Chat Request**.
3. Call **Get Nexus AI Chat Response** with the returned `RequestID` as session Id.
4. Answer only from the RAG body. Prefer tables for past-performance lists.

## Sample prompts (from your files)

Opportunity — see `specs/opportunity-agent-spec.yaml`.  
Contract — see `specs/contract-agent-spec.yaml`.

## Notes

- The Power Automate URL includes a `sig=` query parameter. Rotate that trigger and move it to a Named Credential before sharing the repo widely.
- Agentforce GenAiPlugin field names vary slightly by API 64 vs 65. Treat the plugin XML as a starting point if deploy rejects it.
- No Bot XML is checked in on purpose: an incomplete Employee Bot deploy can fail or create an unusable agent. Create in-org, then retrieve.
